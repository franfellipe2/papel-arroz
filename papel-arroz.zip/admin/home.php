<?php 
$tituloPage  = 'Area administrativa';
require __DIR__ . '/header.php';
require __DIR__ . '/sidebar.php';
?>
<div class="content-page">
Home
</div>
<?php require __DIR__ . '/footer.php'; ?>
</body>
</html>