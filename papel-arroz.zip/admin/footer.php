    </div><!-- .page -->
    <script type="text/javascript" src="assets/js/jquery.js"></script>
    <script type="text/javascript" src="assets/js/datatables.min.js"></script>

