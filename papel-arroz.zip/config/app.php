<?php
return [
    // BANCO DE DADOS
    'dbname' => 'papel_arroz',
    'dbhost' => 'localhost',
    'dbpass' => '',
    'dbuser' => 'root',
    
    
    // SITE
    'baseUrl' => 'http://localhost/papel-arroz',
    'siteName' => 'Papel Arroz Frutal',
    
    // Pastas
    'baseDir' => __DIR__.'/../',
    'frontDir' =>  __DIR__.'/../frontend/'
];
