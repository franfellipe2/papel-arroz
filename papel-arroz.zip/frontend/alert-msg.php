<div class="msg-info smg-info-primary text-center">
    <p><span class="h1"><i class="fas fa-exclamation-triangle"></i> ATENÇÃO:</span> Por Enquanto estamos vendendo somente para a cidade de Frutal - MG.</p>
    <p>Entregas de Segunda a Sexta, das 14:00 as 17:00; e Sábado das 8:00 as 11:00</p>
</div>